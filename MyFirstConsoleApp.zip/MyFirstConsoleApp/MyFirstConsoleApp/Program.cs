﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace MyFirstConsoleApp
{
    class Program
    {
        static void Main()
        {
            // Specify the data source.
            int[] scores = new int[] { 97, 92, 81, 60 };

            // Define the query expression.
            IEnumerable<int> scoreQuery =
                from score in scores
                where score > 80
                select score;

            IEnumerable<int> scoreQuery2 = scores.Where(num => num % 2 == 0).OrderBy(n => n);
            // Execute the query.
            foreach (int i in scoreQuery)
            {
                Console.Write(i + " ");
            }
            Console.WriteLine(System.Environment.NewLine);
            foreach (int i in scoreQuery2)
            {
                Console.Write(i + " ");
            }
            // Keep the console open in debug mode.
            Console.WriteLine(System.Environment.NewLine);
            Console.WriteLine("Press any key to exit");
            Console.ReadKey();
        }
    }
}
